package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Screen;

public interface ListItem {
	void renderInventory(Screen screen, int i, int j);
}
